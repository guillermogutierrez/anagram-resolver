package org.guillermo.anagram.service;

public interface AnagramCalculatorService {

	Integer calculateValue(String word);
}
